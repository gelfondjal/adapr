

rm(list=ls())
set.seed( 2011 )

library(adapr)


source.file <-"summarize_analysis.R"
project.id <- "adaprTest"
source_info <- create_source_file_dir(source.description="make summary markdown")


# Program body here

anovasout <- loadFlex("anova.R/modelfit.RData")
dispHistogram <- loadFlex("graph_cardata.R/disp_histogram.RData")
summarytables <- loadFlex("simple_summary.R/sumaryTables.RData")



# End Program Body


dependency.out <- finalize_dependency()
