

rm(list=ls())
set.seed( 2011 )

library(adapr)


source.file <-"summarize_analysis.R"
project.id <- "adaprTest"
source_info <- create_source_file_dir(source.description="make summary markdown")


# Program body here

anovasout <- Load.branch("anova.R/modelfit.Rdata")
dispHistogram <- Load.branch("graph_cardata.R/disp_histogram.Rdata")
summarytables <- Load.branch("simple_summary.R/sumaryTables.Rdata")



# End Program Body


dependency.out <- finalize_dependency()
