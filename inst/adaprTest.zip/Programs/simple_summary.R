

rm(list=ls())
set.seed( 2011 )

library(adapr)
library(tableone)

source.file <-"simple_summary.R"
project.id <- "adaprTest"
source_info <- create_source_file_dir(source.description="summary by cylinder")


# Program body here


cardata.filtered <- loadFlex("read_data.R/cardata.RData")

# Make a nice table with tableone package

tab <- tableone::CreateTableOne(c("disp","mpg","hp","wt"),"cyl",cardata.filtered)

tabout <- print(tab)

Write(tabout,"sumaryTables.RData","from createTableone by cylinder")

# End Program Body


dependency.out <- finalize_dependency()
