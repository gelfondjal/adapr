

rm(list=ls())
set.seed( 2011 )

library(adapr)


source.file <-"tree_controller.R"
project.id <- "adaprTest"
source_info <- create_source_file_dir(source.description="Operates on analysis tree")


# Program body here




# End Program Body


#synctest.project()     #Tests project synchronization 
#sync.project()  # This runs all programs needed to synchronize
#report.project()              #This summarizes project in html
