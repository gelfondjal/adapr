     

rm(list=ls())
set.seed( 2011 )

library(adapr)
library(dplyr)
 
source.file <-"read_data.R"
project.id <- "adaprTest"
source_info <- create_source_file_dir(source.description="reads data")


# Program body here

# Read data from Data directory, but originally from R base dataset

cardata <- Read("mtcars.csv","cars from R data")

# Examine summary

summarize(cardata)

# It is sometimes easier to filter out or clean data prior to analysis stages

# Filter out 4 cylinder cars

cardata.reduced <- subset(cardata,cyl!=4)

Write(cardata,"cardata.RData","filtered car data")

# End Program Body


dependency.out <- finalize_dependency()
